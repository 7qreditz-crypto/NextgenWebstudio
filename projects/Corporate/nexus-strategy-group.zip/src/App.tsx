/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  BarChart3, 
  ChevronRight, 
  Globe, 
  Mail, 
  MapPin, 
  Phone, 
  ShieldCheck, 
  Target, 
  TrendingUp, 
  Users, 
  Menu, 
  X,
  CheckCircle2,
  ArrowRight,
  Quote
} from 'lucide-react';
import { useForm } from 'react-hook-form';
import { cn } from './lib/utils';

// --- Types ---
interface NavItem {
  label: string;
  href: string;
}

interface Service {
  title: string;
  description: string;
  icon: React.ReactNode;
}

interface CaseStudy {
  client: string;
  title: string;
  result: string;
  stat: string;
  image: string;
}

interface Testimonial {
  quote: string;
  author: string;
  role: string;
  company: string;
  avatar: string;
}

// --- Data ---
const NAV_ITEMS: NavItem[] = [
  { label: 'Services', href: '#services' },
  { label: 'About', href: '#about' },
  { label: 'Case Studies', href: '#case-studies' },
  { label: 'Testimonials', href: '#testimonials' },
];

const SERVICES: Service[] = [
  {
    title: 'Strategic Advisory',
    description: 'Data-driven market analysis and long-term growth strategies for enterprise expansion.',
    icon: <Target className="w-6 h-6" />,
  },
  {
    title: 'Operational Excellence',
    description: 'Streamlining internal processes to maximize efficiency and reduce overhead by up to 30%.',
    icon: <TrendingUp className="w-6 h-6" />,
  },
  {
    title: 'Digital Transformation',
    description: 'Modernizing legacy systems with cutting-edge AI and cloud infrastructure solutions.',
    icon: <Globe className="w-6 h-6" />,
  },
  {
    title: 'Risk Management',
    description: 'Comprehensive auditing and compliance frameworks to protect your global interests.',
    icon: <ShieldCheck className="w-6 h-6" />,
  },
];

const CASE_STUDIES: CaseStudy[] = [
  {
    client: 'Global Logistics Inc.',
    title: 'Supply Chain Optimization',
    result: 'Reduced operational costs by $4.2M annually through automated routing.',
    stat: '22% ROI',
    image: 'https://images.unsplash.com/photo-1586528116311-ad8dd3c8310d?auto=format&fit=crop&q=80&w=800',
  },
  {
    client: 'FinTech Solutions',
    title: 'Market Entry Strategy',
    result: 'Successfully launched in 4 new European markets within 12 months.',
    stat: '3.5x Growth',
    image: 'https://images.unsplash.com/photo-1551288049-bebda4e38f71?auto=format&fit=crop&q=80&w=800',
  },
  {
    client: 'TechCorp International',
    title: 'Digital Infrastructure Overhaul',
    result: 'Migrated 100% of legacy data to secure cloud with zero downtime.',
    stat: '99.9% Uptime',
    image: 'https://images.unsplash.com/photo-1451187580459-43490279c0fa?auto=format&fit=crop&q=80&w=800',
  },
];

const TESTIMONIALS: Testimonial[] = [
  {
    quote: "Nexus Strategy Group transformed our approach to global expansion. Their insights were not just theoretical, but immediately actionable.",
    author: "Sarah Jenkins",
    role: "CEO",
    company: "Lumina Global",
    avatar: "https://i.pravatar.cc/150?u=sarah",
  },
  {
    quote: "The level of professionalism and depth of analysis provided by the team exceeded all our expectations. They are true partners in our success.",
    author: "Marcus Thorne",
    role: "COO",
    company: "Apex Industries",
    avatar: "https://i.pravatar.cc/150?u=marcus",
  },
];

const LOGOS = [
  'Microsoft', 'Goldman Sachs', 'Deloitte', 'Accenture', 'IBM', 'Oracle'
];

// --- Components ---

const Navbar = () => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => setIsScrolled(window.scrollY > 20);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <nav className={cn(
      "fixed top-0 left-0 right-0 z-50 transition-all duration-300 px-6 py-4",
      isScrolled ? "bg-white/90 backdrop-blur-md shadow-sm border-b border-slate-100 py-3" : "bg-transparent"
    )}>
      <div className="max-w-7xl mx-auto flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="w-10 h-10 bg-brand-900 rounded-lg flex items-center justify-center">
            <BarChart3 className="text-white w-6 h-6" />
          </div>
          <span className={cn("text-xl font-bold tracking-tight", isScrolled ? "text-brand-950" : "text-brand-950")}>
            NEXUS<span className="text-brand-600">STRATEGY</span>
          </span>
        </div>

        {/* Desktop Nav */}
        <div className="hidden md:flex items-center gap-8">
          {NAV_ITEMS.map((item) => (
            <a 
              key={item.label} 
              href={item.href}
              className="text-sm font-medium text-slate-600 hover:text-brand-600 transition-colors"
            >
              {item.label}
            </a>
          ))}
          <button className="bg-brand-900 text-white px-5 py-2.5 rounded-full text-sm font-semibold hover:bg-brand-800 transition-all shadow-lg shadow-brand-900/20 active:scale-95">
            Book Consultation
          </button>
        </div>

        {/* Mobile Toggle */}
        <button 
          className="md:hidden text-slate-900"
          onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
        >
          {isMobileMenuOpen ? <X /> : <Menu />}
        </button>
      </div>

      {/* Mobile Menu */}
      <AnimatePresence>
        {isMobileMenuOpen && (
          <motion.div 
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="absolute top-full left-0 right-0 bg-white border-b border-slate-100 p-6 flex flex-col gap-4 md:hidden shadow-xl"
          >
            {NAV_ITEMS.map((item) => (
              <a 
                key={item.label} 
                href={item.href}
                className="text-lg font-medium text-slate-900"
                onClick={() => setIsMobileMenuOpen(false)}
              >
                {item.label}
              </a>
            ))}
            <button className="bg-brand-900 text-white px-5 py-3 rounded-xl text-center font-semibold">
              Book Consultation
            </button>
          </motion.div>
        )}
      </AnimatePresence>
    </nav>
  );
};

const Hero = () => {
  return (
    <section className="relative pt-32 pb-20 lg:pt-48 lg:pb-32 overflow-hidden">
      {/* Background Accents */}
      <div className="absolute top-0 right-0 -translate-y-1/4 translate-x-1/4 w-[600px] h-[600px] bg-brand-50 rounded-full blur-3xl opacity-50 -z-10" />
      <div className="absolute bottom-0 left-0 translate-y-1/4 -translate-x-1/4 w-[400px] h-[400px] bg-brand-100 rounded-full blur-3xl opacity-30 -z-10" />

      <div className="max-w-7xl mx-auto px-6 grid lg:grid-cols-2 gap-12 items-center">
        <motion.div
          initial={{ opacity: 0, x: -30 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.6 }}
        >
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-brand-50 border border-brand-100 text-brand-700 text-xs font-bold uppercase tracking-wider mb-6">
            <CheckCircle2 className="w-4 h-4" /> Trusted by Fortune 500 Enterprises
          </div>
          <h1 className="text-5xl lg:text-7xl font-bold text-brand-950 leading-[1.1] mb-6">
            Accelerate Your <span className="text-brand-600">Enterprise</span> Growth with Precision.
          </h1>
          <p className="text-xl text-slate-600 mb-10 leading-relaxed max-w-xl">
            Nexus Strategy Group provides high-impact consultancy for global leaders. We turn complex business challenges into measurable ROI through data-driven strategies.
          </p>
          <div className="flex flex-col sm:flex-row gap-4">
            <button className="bg-brand-900 text-white px-8 py-4 rounded-full text-lg font-bold hover:bg-brand-800 transition-all shadow-xl shadow-brand-900/20 flex items-center justify-center gap-2 group">
              Book a Consultation <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
            </button>
            <button className="bg-white text-slate-900 border border-slate-200 px-8 py-4 rounded-full text-lg font-bold hover:bg-slate-50 transition-all flex items-center justify-center gap-2">
              View Case Studies
            </button>
          </div>
          
          <div className="mt-12 flex items-center gap-8">
            <div>
              <div className="text-3xl font-bold text-brand-950">500+</div>
              <div className="text-sm text-slate-500 font-medium">Projects Delivered</div>
            </div>
            <div className="w-px h-10 bg-slate-200" />
            <div>
              <div className="text-3xl font-bold text-brand-950">$2.4B</div>
              <div className="text-sm text-slate-500 font-medium">Client Value Created</div>
            </div>
            <div className="w-px h-10 bg-slate-200" />
            <div>
              <div className="text-3xl font-bold text-brand-950">15+</div>
              <div className="text-sm text-slate-500 font-medium">Global Offices</div>
            </div>
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.8, delay: 0.2 }}
          className="relative"
        >
          <div className="relative rounded-2xl overflow-hidden shadow-2xl">
            <img 
              src="https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?auto=format&fit=crop&q=80&w=1200" 
              alt="Corporate Building" 
              className="w-full h-[600px] object-cover"
              referrerPolicy="no-referrer"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-brand-950/40 to-transparent" />
          </div>
          
          {/* Floating Card */}
          <motion.div 
            animate={{ y: [0, -10, 0] }}
            transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }}
            className="absolute -bottom-6 -left-6 bg-white p-6 rounded-xl shadow-2xl border border-slate-100 max-w-[240px]"
          >
            <div className="flex items-center gap-3 mb-3">
              <div className="w-10 h-10 bg-green-100 rounded-full flex items-center justify-center">
                <TrendingUp className="text-green-600 w-5 h-5" />
              </div>
              <div className="text-sm font-bold text-slate-900">Performance Index</div>
            </div>
            <div className="text-2xl font-bold text-brand-950">+142%</div>
            <p className="text-xs text-slate-500 mt-1">Average efficiency increase across all digital transformation projects in 2025.</p>
          </motion.div>
        </motion.div>
      </div>
    </section>
  );
};

const LogoCloud = () => {
  return (
    <section className="py-12 border-y border-slate-100 bg-slate-50/50">
      <div className="max-w-7xl mx-auto px-6">
        <p className="text-center text-sm font-bold text-slate-400 uppercase tracking-widest mb-10">
          Empowering the world's most ambitious organizations
        </p>
        <div className="flex flex-wrap justify-center items-center gap-x-16 gap-y-8 opacity-50 grayscale hover:grayscale-0 transition-all duration-500">
          {LOGOS.map((logo) => (
            <span key={logo} className="text-2xl font-black text-slate-900 tracking-tighter italic">
              {logo}
            </span>
          ))}
        </div>
      </div>
    </section>
  );
};

const Services = () => {
  return (
    <section id="services" className="py-24 bg-white">
      <div className="max-w-7xl mx-auto px-6">
        <div className="text-center max-w-3xl mx-auto mb-20">
          <h2 className="text-brand-600 font-bold text-sm uppercase tracking-widest mb-4">Our Expertise</h2>
          <h3 className="text-4xl lg:text-5xl font-bold text-brand-950 mb-6">Tailored Solutions for Global Enterprise Challenges</h3>
          <p className="text-lg text-slate-600">
            We combine deep industry knowledge with advanced analytics to deliver results that matter to your bottom line.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          {SERVICES.map((service, idx) => (
            <motion.div
              key={service.title}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ delay: idx * 0.1 }}
              viewport={{ once: true }}
              className="p-8 rounded-2xl border border-slate-100 bg-white hover:shadow-xl hover:border-brand-100 transition-all group"
            >
              <div className="w-14 h-14 bg-brand-50 rounded-xl flex items-center justify-center text-brand-600 mb-6 group-hover:bg-brand-600 group-hover:text-white transition-colors">
                {service.icon}
              </div>
              <h4 className="text-xl font-bold text-brand-950 mb-4">{service.title}</h4>
              <p className="text-slate-600 leading-relaxed mb-6">{service.description}</p>
              <a href="#" className="inline-flex items-center gap-2 text-brand-600 font-bold text-sm group-hover:gap-3 transition-all">
                Learn More <ChevronRight className="w-4 h-4" />
              </a>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

const CaseStudies = () => {
  return (
    <section id="case-studies" className="py-24 bg-brand-950 text-white overflow-hidden">
      <div className="max-w-7xl mx-auto px-6">
        <div className="flex flex-col lg:flex-row lg:items-end justify-between mb-16 gap-8">
          <div className="max-w-2xl">
            <h2 className="text-brand-400 font-bold text-sm uppercase tracking-widest mb-4">Case Studies</h2>
            <h3 className="text-4xl lg:text-5xl font-bold mb-6">Proven Results Across Industries</h3>
            <p className="text-brand-200/70 text-lg">
              Our work speaks for itself. Explore how we've helped enterprises achieve unprecedented growth and operational efficiency.
            </p>
          </div>
          <button className="text-white border border-white/20 px-8 py-4 rounded-full font-bold hover:bg-white/10 transition-all">
            View All Success Stories
          </button>
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          {CASE_STUDIES.map((study, idx) => (
            <motion.div
              key={study.client}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ delay: idx * 0.1 }}
              viewport={{ once: true }}
              className="group cursor-pointer"
            >
              <div className="relative h-[400px] rounded-2xl overflow-hidden mb-6">
                <img 
                  src={study.image} 
                  alt={study.client} 
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-brand-950 via-brand-950/20 to-transparent opacity-80" />
                <div className="absolute bottom-6 left-6 right-6">
                  <div className="text-brand-400 font-bold text-xs uppercase tracking-widest mb-2">{study.client}</div>
                  <h4 className="text-2xl font-bold mb-4">{study.title}</h4>
                  <div className="inline-block bg-brand-600 px-4 py-2 rounded-lg font-bold text-sm">
                    {study.stat}
                  </div>
                </div>
              </div>
              <p className="text-brand-200/60 leading-relaxed">{study.result}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

const Testimonials = () => {
  return (
    <section id="testimonials" className="py-24 bg-slate-50">
      <div className="max-w-7xl mx-auto px-6">
        <div className="text-center mb-20">
          <h2 className="text-brand-600 font-bold text-sm uppercase tracking-widest mb-4">Testimonials</h2>
          <h3 className="text-4xl lg:text-5xl font-bold text-brand-950">What Global Leaders Say</h3>
        </div>

        <div className="grid md:grid-cols-2 gap-8">
          {TESTIMONIALS.map((t, idx) => (
            <motion.div
              key={t.author}
              initial={{ opacity: 0, scale: 0.95 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              className="bg-white p-10 rounded-3xl shadow-sm border border-slate-100 relative"
            >
              <Quote className="absolute top-10 right-10 w-12 h-12 text-brand-50" />
              <p className="text-xl text-slate-700 italic leading-relaxed mb-8 relative z-10">
                "{t.quote}"
              </p>
              <div className="flex items-center gap-4">
                <img src={t.avatar} alt={t.author} className="w-14 h-14 rounded-full object-cover" referrerPolicy="no-referrer" />
                <div>
                  <div className="font-bold text-brand-950">{t.author}</div>
                  <div className="text-sm text-slate-500">{t.role}, {t.company}</div>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

const Contact = () => {
  const { register, handleSubmit, formState: { errors, isSubmitting } } = useForm();
  const [submitted, setSubmitted] = useState(false);

  const onSubmit = (data: any) => {
    console.log('Lead generated:', data);
    setSubmitted(true);
  };

  return (
    <section id="contact" className="py-24 bg-white">
      <div className="max-w-7xl mx-auto px-6">
        <div className="bg-brand-900 rounded-[40px] overflow-hidden shadow-2xl flex flex-col lg:flex-row">
          <div className="lg:w-1/2 p-12 lg:p-20 text-white">
            <h2 className="text-4xl lg:text-6xl font-bold mb-8">Ready to Transform Your Business?</h2>
            <p className="text-brand-100 text-xl mb-12 leading-relaxed">
              Schedule a confidential consultation with our senior partners to discuss your strategic objectives.
            </p>
            
            <div className="space-y-6">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 bg-brand-800 rounded-full flex items-center justify-center">
                  <Phone className="w-6 h-6" />
                </div>
                <div>
                  <div className="text-sm text-brand-300">Global Hotline</div>
                  <div className="text-lg font-bold">+1 (800) NEXUS-STRAT</div>
                </div>
              </div>
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 bg-brand-800 rounded-full flex items-center justify-center">
                  <Mail className="w-6 h-6" />
                </div>
                <div>
                  <div className="text-sm text-brand-300">Email Inquiry</div>
                  <div className="text-lg font-bold">consult@nexus-strategy.com</div>
                </div>
              </div>
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 bg-brand-800 rounded-full flex items-center justify-center">
                  <MapPin className="w-6 h-6" />
                </div>
                <div>
                  <div className="text-sm text-brand-300">Headquarters</div>
                  <div className="text-lg font-bold">Wall Street, New York, NY</div>
                </div>
              </div>
            </div>
          </div>

          <div className="lg:w-1/2 bg-white p-12 lg:p-20">
            {submitted ? (
              <motion.div 
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                className="h-full flex flex-col items-center justify-center text-center"
              >
                <div className="w-20 h-20 bg-green-100 text-green-600 rounded-full flex items-center justify-center mb-6">
                  <CheckCircle2 className="w-10 h-10" />
                </div>
                <h3 className="text-3xl font-bold text-brand-950 mb-4">Request Received</h3>
                <p className="text-slate-600">A senior partner will contact you within 24 business hours to confirm your consultation.</p>
              </motion.div>
            ) : (
              <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
                <div className="grid md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <label className="text-sm font-bold text-slate-700">Full Name</label>
                    <input 
                      {...register('name', { required: true })}
                      placeholder="John Doe"
                      className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:border-brand-600 focus:ring-2 focus:ring-brand-100 outline-none transition-all"
                    />
                    {errors.name && <span className="text-red-500 text-xs">This field is required</span>}
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm font-bold text-slate-700">Work Email</label>
                    <input 
                      {...register('email', { required: true, pattern: /^\S+@\S+$/i })}
                      placeholder="john@company.com"
                      className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:border-brand-600 focus:ring-2 focus:ring-brand-100 outline-none transition-all"
                    />
                    {errors.email && <span className="text-red-500 text-xs">Valid email required</span>}
                  </div>
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-bold text-slate-700">Company Name</label>
                  <input 
                    {...register('company', { required: true })}
                    placeholder="Enter your organization"
                    className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:border-brand-600 focus:ring-2 focus:ring-brand-100 outline-none transition-all"
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-bold text-slate-700">Service Interest</label>
                  <select 
                    {...register('service')}
                    className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:border-brand-600 focus:ring-2 focus:ring-brand-100 outline-none transition-all appearance-none bg-white"
                  >
                    <option>Strategic Advisory</option>
                    <option>Operational Excellence</option>
                    <option>Digital Transformation</option>
                    <option>Risk Management</option>
                  </select>
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-bold text-slate-700">Message (Optional)</label>
                  <textarea 
                    {...register('message')}
                    rows={4}
                    placeholder="Tell us about your objectives..."
                    className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:border-brand-600 focus:ring-2 focus:ring-brand-100 outline-none transition-all resize-none"
                  />
                </div>
                <button 
                  disabled={isSubmitting}
                  className="w-full bg-brand-900 text-white py-4 rounded-xl font-bold text-lg hover:bg-brand-800 transition-all shadow-lg shadow-brand-900/20 disabled:opacity-50"
                >
                  {isSubmitting ? 'Processing...' : 'Schedule Free Consultation'}
                </button>
                <p className="text-center text-xs text-slate-400">
                  By submitting, you agree to our privacy policy and terms of service.
                </p>
              </form>
            )}
          </div>
        </div>
      </div>
    </section>
  );
};

const Footer = () => {
  return (
    <footer className="bg-slate-950 text-white pt-20 pb-10">
      <div className="max-w-7xl mx-auto px-6">
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-12 mb-20">
          <div className="space-y-6">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 bg-brand-600 rounded flex items-center justify-center">
                <BarChart3 className="text-white w-5 h-5" />
              </div>
              <span className="text-xl font-bold tracking-tight">
                NEXUS<span className="text-brand-500">STRATEGY</span>
              </span>
            </div>
            <p className="text-slate-400 leading-relaxed">
              Leading global consultancy empowering enterprises to navigate complexity and achieve sustainable growth through innovation.
            </p>
            <div className="flex gap-4">
              {['LinkedIn', 'Twitter', 'Forbes'].map(social => (
                <a key={social} href="#" className="text-slate-500 hover:text-white transition-colors text-sm font-bold uppercase tracking-widest">
                  {social}
                </a>
              ))}
            </div>
          </div>

          <div>
            <h5 className="font-bold mb-6 text-lg">Services</h5>
            <ul className="space-y-4 text-slate-400">
              <li><a href="#" className="hover:text-brand-400 transition-colors">Strategic Advisory</a></li>
              <li><a href="#" className="hover:text-brand-400 transition-colors">Operational Excellence</a></li>
              <li><a href="#" className="hover:text-brand-400 transition-colors">Digital Transformation</a></li>
              <li><a href="#" className="hover:text-brand-400 transition-colors">Risk Management</a></li>
              <li><a href="#" className="hover:text-brand-400 transition-colors">M&A Advisory</a></li>
            </ul>
          </div>

          <div>
            <h5 className="font-bold mb-6 text-lg">Company</h5>
            <ul className="space-y-4 text-slate-400">
              <li><a href="#" className="hover:text-brand-400 transition-colors">About Us</a></li>
              <li><a href="#" className="hover:text-brand-400 transition-colors">Our Partners</a></li>
              <li><a href="#" className="hover:text-brand-400 transition-colors">Global Offices</a></li>
              <li><a href="#" className="hover:text-brand-400 transition-colors">Careers</a></li>
              <li><a href="#" className="hover:text-brand-400 transition-colors">Contact</a></li>
            </ul>
          </div>

          <div>
            <h5 className="font-bold mb-6 text-lg">Newsletter</h5>
            <p className="text-slate-400 text-sm mb-6">Get strategic insights delivered to your inbox weekly.</p>
            <div className="flex gap-2">
              <input 
                type="email" 
                placeholder="Email address" 
                className="bg-slate-900 border border-slate-800 rounded-lg px-4 py-2 text-sm outline-none focus:border-brand-600 w-full"
              />
              <button className="bg-brand-600 px-4 py-2 rounded-lg font-bold text-sm hover:bg-brand-500 transition-colors">
                Join
              </button>
            </div>
          </div>
        </div>

        <div className="pt-10 border-t border-slate-900 flex flex-col md:flex-row justify-between items-center gap-6 text-slate-500 text-sm">
          <p>© 2026 Nexus Strategy Group. All rights reserved.</p>
          <div className="flex gap-8">
            <a href="#" className="hover:text-white transition-colors">Privacy Policy</a>
            <a href="#" className="hover:text-white transition-colors">Terms of Service</a>
            <a href="#" className="hover:text-white transition-colors">Cookie Policy</a>
          </div>
        </div>
      </div>
    </footer>
  );
};

const About = () => {
  return (
    <section id="about" className="py-24 bg-slate-50">
      <div className="max-w-7xl mx-auto px-6 grid lg:grid-cols-2 gap-16 items-center">
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          whileInView={{ opacity: 1, x: 0 }}
          viewport={{ once: true }}
          className="relative"
        >
          <div className="aspect-square rounded-3xl overflow-hidden shadow-2xl">
            <img 
              src="https://images.unsplash.com/photo-1522071820081-009f0129c71c?auto=format&fit=crop&q=80&w=1000" 
              alt="Team Collaboration" 
              className="w-full h-full object-cover"
              referrerPolicy="no-referrer"
            />
          </div>
          <div className="absolute -bottom-10 -right-10 bg-brand-900 text-white p-8 rounded-2xl shadow-2xl hidden md:block">
            <div className="text-4xl font-bold mb-1">25+</div>
            <div className="text-sm font-medium text-brand-200">Years of Strategic Excellence</div>
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, x: 20 }}
          whileInView={{ opacity: 1, x: 0 }}
          viewport={{ once: true }}
        >
          <h2 className="text-brand-600 font-bold text-sm uppercase tracking-widest mb-4">Our Mission</h2>
          <h3 className="text-4xl lg:text-5xl font-bold text-brand-950 mb-6">Empowering Leaders to Redefine What's Possible</h3>
          <p className="text-lg text-slate-600 mb-8 leading-relaxed">
            Founded in 2001, Nexus Strategy Group was built on a single principle: that data-driven insights combined with human ingenuity can solve the world's most complex business problems.
          </p>
          
          <div className="space-y-6 mb-10">
            {[
              { title: "Integrity First", desc: "Transparent advisory that prioritizes your long-term success over short-term gains." },
              { title: "Global Perspective", desc: "Our network spans 4 continents, providing local insights with global reach." },
              { title: "Result-Oriented", desc: "We don't just deliver reports; we deliver measurable business outcomes." }
            ].map((item) => (
              <div key={item.title} className="flex gap-4">
                <div className="mt-1">
                  <CheckCircle2 className="w-6 h-6 text-brand-600" />
                </div>
                <div>
                  <h4 className="font-bold text-brand-950">{item.title}</h4>
                  <p className="text-slate-500 text-sm">{item.desc}</p>
                </div>
              </div>
            ))}
          </div>

          <button className="bg-brand-900 text-white px-8 py-4 rounded-full font-bold hover:bg-brand-800 transition-all shadow-lg shadow-brand-900/20">
            Meet Our Partners
          </button>
        </motion.div>
      </div>
    </section>
  );
};

export default function App() {
  return (
    <div className="min-h-screen selection:bg-brand-100 selection:text-brand-900">
      <Navbar />
      <main>
        <Hero />
        <LogoCloud />
        <About />
        <Services />
        <CaseStudies />
        <Testimonials />
        <Contact />
      </main>
      <Footer />
    </div>
  );
}
